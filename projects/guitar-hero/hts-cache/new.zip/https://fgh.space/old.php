<HTML><HEAD>
    <TITLE>FGH: Online Guitar Hero and Rock Band analog</TITLE>
    <META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8" />
    <META name="description" content="Online Guitar Hero and Rock Band analog. Play with your Friends and thousands of other Players!" />
    
    <META property="og:site_name" content="FGH"/>
    <META property="og:url" content="https://fgh.space"/>
    <META property="og:title" content="FGH: Online Guitar Hero and Rock Band analog"/>
    <META property="og:description" content="Online Guitar Hero and Rock Band analog. Play with your Friends and thousands of other Players!"/>
    <META property="og:image" content="https://fgh.space/images/logo256.png"/>
    <META property="og:type" content="website"/>
    
    <link rel="shortcut icon" type="image/x-icon" href="/favicon.ico">

  	<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
    <script src="//code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
    <script type="text/javascript" src="js/browser_detect.js"></script>
    <script type="text/javascript" src="js/allapi.js?6"></script>
    <script type="text/javascript" src="js/script.js?15"></script>
    <script type="text/javascript" src="js/jquery.cookie.js"></script>
    <link href='//fonts.googleapis.com/css?family=Roboto+Condensed&subset=cyrillic,latin' rel='stylesheet' type='text/css'>
    <link href='//fonts.googleapis.com/css?family=Lobster&subset=cyrillic,latin' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" type="text/css" href="style/style.css?6">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</HEAD>
<BODY>
<script type="text/javascript">
var vkAuthProcFlag=false;
var fbAuthProcFlag=false;
var lang = 'en';
var pay_type = 'usd';
var VK_APPID='4429429';
var ML_APPID='729711';
var ML_APPKEY='9d99fde988a54b4ed8245fd9b21129ab';
var FB_APPID='334690486687600';
var GP_APPID='112599253857-ncqf659gb8f00tfjhs9q6ug8bhn7u384.apps.googleusercontent.com';
var GP_APPKEY='AIzaSyB-zOkVYpOZ7zCAWorG6iJbUqHuCMJKX3c';

var social;
var social_id;
var user_id;

var page_title='FGH: Online Guitar Hero and Rock Band analog';
var page_description='Online Guitar Hero and Rock Band analog. Play with your Friends and thousands of other Players!';
var not_available='Sorry, but this feature is not available in the current social network!';

function getSID(){
	return 's4a1t3e30kte5qa8eijuolm8p6'
}
function initPreBanner(){

}
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
    m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-55176939-1', 'auto');
ga('send', 'pageview');


/*
window.fbAsyncInit = function() {
    FB.init({
        appId      : '334690486687600',
        cookie     : true,
        xfbml      : true,
        version    : 'v6.0'
    });

    FB.AppEvents.logPageView();

};

(function(d, s, id){
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) {return;}
    js = d.createElement(s); js.id = id;
    js.src = "https://connect.facebook.net/en_US/sdk.js";
    fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));
*/
</script>
<div id='iframe'>
    <div id='close_btn'></div>
    	<div id='en_lng' class='active'></div>
                <div id='ru_lng'></div>    <div id='signin'>
        <div id='main_logo'></div>
        <h1 itemprop="name">FGH: Online Guitar Hero and Rock Band analog</h1>

        <h3>Play with your Friends and thousands of other Players!<br>Become a ROCK legend!</h3>


        <div id="intro">
            <p id="error_message">To play the game you will need to use your social network account.<br>You can use different features depending on your social network type</p>
            <br>
            <br>
<!--
            <script src="//ulogin.ru/js/ulogin.js"></script>
            <div id="uLogin" data-ulogin="display=panel;fields=first_name,last_name,email,sex,photo_big;mobilebuttons=0;sort=default;theme=flat;providers=twitter,google,vkontakte,odnoklassniki,mailru;redirect_uri=;callback=uLoginProc"></div>
-->
<script src="//ulogin.ru/js/ulogin.js"></script><div id="uLogin_5146aa17" data-uloginid="5146aa17"></div>
        </div>

        <div id="footer"><span class="left">If you have any questions or suggestions,<br>please, <a href="https://discord.gg/vP4SzTq" target="_blank">visit our Discord channel</a> and subscribe to us</span><span class="group_btn fb"
                                                                                                 link="//facebook.com/fghpage"></span><span
                class="group_btn tw" link="//twitter.com/flashguitarhero"></span><span class="group_btn vk"
                                                                                              link="//vk.com/clubfgh"></span><span
                class="right"><a href="https://discord.gg/vP4SzTq"
                                 target="_blank">Get to know more about FGH community</a></span>
        </div>
    </div>
        <iframe id='pw' src="" frameborder=0 width=800 height=600></iframe>
    <div id="swf_place"></div>
    <div id="chat_container"></div>
    <div id="navigation"><a href="/">Home</a> | <a href="https://discord.gg/vP4SzTq">Discord FGH Community</a> | <a href="/privacypolicy">Privacy Policy</a></div>
    <div style="float:right"><a href="//www.free-kassa.ru/"><img src="//www.free-kassa.ru/img/fk_btn/14.png"></a></div>

</div>
<br>
</BODY></HTML>
